define("app/controllers/application", 
  ["exports"],
  function(__exports__) {
    "use strict";
    __exports__["default"] = Em.Controller.extend({
    	order: null
    });
  });